const TelefoneController = require('../controllers/Telefonecontrollers');

module.exports = (router) => {
   router.get('/Telefonica', TelefoneController.get);
}