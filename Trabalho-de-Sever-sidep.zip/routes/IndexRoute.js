module.exports = (router) => {
   router.get('/', (req, res) => {
      res.json({msg: 'API RESTFul Telefônica by:Victor Hugo', version: '1.0.0'});
   });
}