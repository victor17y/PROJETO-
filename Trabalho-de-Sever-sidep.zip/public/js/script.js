function mostrarTelefonicas(telefonicas){
	const galeriaTelefonicas = document.querySelector(".mostrarTelefones")
	
	for(let i = 0; i < telefonicas.length; i++){

    const linkTelefonica = document.createElement("a");
    const imgTelefonica = document.createElement("img");   
		const desTelefonica = document.createElement("div");
    
		desTelefonica.innerHTML = "<p>" + "<b>" + "Nome: " + "</b>" + telefonicas[i].nome + "</p>" + "<p>" + "<b>" + "Número: " + "</b>" + telefonicas[i].numero + "</p>" + "<p>" + "<b>" + "CPF: " + "</b>" + telefonicas[i].cpf + "</p>";
    
		linkTelefonica.href = 'api/Telefonica/' + telefonicas[i].id;
		linkTelefonica.title = telefonicas[i].nome;
		imgTelefonica.src = telefonicas[i].img_capa;
    imgTelefonica.alt = telefonicas[i].nome;
		imgTelefonica.className = "telefonicas";
		desTelefonica.className = "desTelefonicas";

		linkTelefonica.append(imgTelefonica);
		linkTelefonica.append(desTelefonica);
		galeriaTelefonicas.append(linkTelefonica);
	}
}

listarTelefonicasService();

async function listarTelefonicasService() {
    const resposta = await fetch("api/Telefonica");
    const telefonicas = await resposta.json();
    mostrarTelefonicas(telefonicas);
}