module.exports = class Telefone{
	constructor({id, nome, numero, cpf, img_capa}){
    this.id = id || Math.floor(+new Date() / 1000);
    this.nome = nome;
		this.numero = numero;
		this.cpf = cpf;
    this.img_capa = img_capa;
  }
}