const Telefone = require('../models/Telefone');
const Telefonica = require('../database/data').carregarTelefonica || [];

exports.get = (req, res) => {
   const { numero } = req.query;
   if(numero){
      return res.json(
         Telefonica.filter(Telefone =>Telefone.numero.toLowerCase()
            .includes(numero.toLowerCase()))
      );
   }
   res.json(Telefonica);
};