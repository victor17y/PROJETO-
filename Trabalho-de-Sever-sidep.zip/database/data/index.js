//Aqui estamos chamando os arquivos necessários para o funcionamneto desse trecho
const Telefonica = require("./Telefonica.json")
const Telefone = require("../../models/Telefone")

//Função responsável por adicionar novos objetos que forem cadastrados
const carregarTelefonica = (()=>{
	const lista = []
	for(i in Telefonica){
		lista.push(new Telefone(Telefonica[i]))
	}
	return lista
})()
//Aqui estamos exportando a função carregarProdutos para ser utilizada em outro arquivo
module.exports = {
  carregarTelefonica
}